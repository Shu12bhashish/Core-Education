# Core-edu

## Overview My Project
In this project is a landing page for education purpose. Here I use only:-
- HTML
- CSS
- Bootsrap

## Live site link: 
- https://core-edu.netlify.app/
